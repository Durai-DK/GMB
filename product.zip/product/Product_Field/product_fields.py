

class ProductField(object):
               ##########################################################
    Title = """You Can Now Get Upto 10%* Inst. Discount on Smart Speakers"""
    Category = "Christmas & New Year Deals"
    Description = """Celebrate Christmas with Poorvika's Christmas & New Year Deals. Get Smart Speakers for your Home like Amazon Echo, Mi Smart Speaker, Google Home & More from just ₹1,999* Now with Upto 10%* HDFC Instant Discount. Just Visit Poorvika Online to grab this awesome deal right away!"""
    Image = r"D:\Durai\GMB\product\image\23-12-2022-1.jpeg"
    Field = "Get offer"
    Online_Link = "http://bit.ly/3HU7G3k"




